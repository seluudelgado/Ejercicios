<?php
    define('servidor','localhost');
    define('usuario','root');
    define('basedatos','VisitasJesuitas');
    define('password','');
?>
